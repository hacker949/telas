<meta charset="utf-8"/>
<?php
    
    $arquivo = file_get_contents("https://raw.githubusercontent.com/emersonsoares/SampleDataGenerator/master/SampleDataGenerator/Resources/nomes.txt");
    $emails = explode("\n", $arquivo);
    ?>